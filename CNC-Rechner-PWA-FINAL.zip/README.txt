CNC-Rechner – PWA package for GitHub Pages / PWABuilder

Upload ALL files in this folder directly into:
https://guettouchiislam-design.github.io/recher/

Required names (do not add [1] to the names):
index.html
manifest.json
sw.js
icon-32.png
icon-180.png
icon-192.png
icon-512.png

The manifest includes:
- id
- start_url
- scope
- 192x192 icon
- 512x512 icon
- categories
- screenshots (if generated)

After uploading, open:
https://guettouchiislam-design.github.io/recher/

Then refresh PWABuilder for the same URL.
